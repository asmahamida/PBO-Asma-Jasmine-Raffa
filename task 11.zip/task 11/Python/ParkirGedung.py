# Nama Program        : Gaji Pegawai
# Nama NPM Anggota 1  : Jasmine Salsabila (140810250017)
# Nama NPM Anggota 2  : Raffa Pasha Hidayat (140810250043)
# Nama NPM Anggota 3  : Asma Hamidah (140810250053)
# Tanggal Pengerjaan  : 10 November 2026
# Deskripsi           : Program Sistem Parkir Gedung merupakan program berbasis Java yang digunakan untuk mengelola data parkir kendaraan, baik untuk pengguna umum maupun pegawai. Program ini mencatat identitas pengguna, jenis kendaraan, lokasi parkir, tanggal dan waktu masuk, serta durasi parkir. Biaya parkir dihitung berdasarkan jenis kendaraan, status pengguna, dan lama parkir, dengan penerapan diskon bagi pengguna umum sesuai ketentuan kunjungan. Program ini menerapkan konsep OOP, meliputi encapsulation, inheritance, polymorphism, abstraction, dan composition.


from datetime import datetime, timedelta, date
from abc import ABC, abstractmethod
import math


# ==================== CLASS WAKTU ====================

class Waktu:
    def __init__(self, jam=0, menit=0, detik=0):
        self.__jam = jam
        self.__menit = menit
        self.__detik = detik

    def getJam(self):
        return self.__jam

    def getMenit(self):
        return self.__menit

    def getDetik(self):
        return self.__detik

    def inputWaktu(self):
        self.__jam = int(input("Jam   : "))
        self.__menit = int(input("Menit : "))
        self.__detik = int(input("Detik : "))

    def toSecond(self):
        return self.__jam * 3600 + self.__menit * 60 + self.__detik

    def outputWaktu(self):
        print(
            f"{self.__jam:02d}:{self.__menit:02d}:{self.__detik:02d}",
            end=""
        )


# ==================== CLASS PERSON ====================

class Person:
    def __init__(self, nama, alamat):
        self.__nama = nama
        self.__alamat = alamat

    def getNama(self):
        return self.__nama

    def getAlamat(self):
        return self.__alamat

    def output(self):
        print("Nama           :", self.__nama)
        print("Alamat         :", self.__alamat)


# ==================== CLASS KENDARAAN ====================

class Kendaraan(ABC):
    def __init__(self, nomorPlat):
        self.nomorPlat = nomorPlat

    def getNomorPlat(self):
        return self.nomorPlat

    @abstractmethod
    def getTarifUmum(self):
        pass

    @abstractmethod
    def getTarifPegawai(self):
        pass

    @abstractmethod
    def getJenis(self):
        pass

    def hitungBiayaUmum(self, jam):
        return self.getTarifUmum() * jam

    def hitungBiayaPegawai(self, hari):
        return self.getTarifPegawai() * hari


class Mobil(Kendaraan):
    def getTarifUmum(self):
        return 3000

    def getTarifPegawai(self):
        return 6000

    def getJenis(self):
        return "Mobil"


class Truk(Kendaraan):
    def getTarifUmum(self):
        return 5000

    def getTarifPegawai(self):
        return 5000

    def getJenis(self):
        return "Truk"


class Motor(Kendaraan):
    def getTarifUmum(self):
        return 2000

    def getTarifPegawai(self):
        return 3000

    def getJenis(self):
        return "Motor"


# ==================== CLASS PARKIR ====================

class Parkir:
    def __init__(self, kode, person, kendaraan, pegawai,
                 nip, tanggal, waktuMasuk, lamaParkir,
                 kunjungan):

        self.__kode = kode
        self.__person = person
        self.__kendaraan = kendaraan
        self.__pegawai = pegawai
        self.__nip = nip

        self.__tanggal = tanggal
        self.__waktuMasuk = waktuMasuk
        self.__lamaParkir = lamaParkir

        self.__kunjungan = kunjungan
        self.__lokasi = ""

    def getKendaraan(self):
        return self.__kendaraan

    def isPegawai(self):
        return self.__pegawai

    def getTanggal(self):
        return self.__tanggal

    def getKunjungan(self):
        return self.__kunjungan

    def setLokasi(self, lokasi):
        self.__lokasi = lokasi

    def getWaktuKeluar(self):
        masuk = datetime(
            self.__tanggal.year,
            self.__tanggal.month,
            self.__tanggal.day,
            self.__waktuMasuk.getJam(),
            self.__waktuMasuk.getMenit(),
            self.__waktuMasuk.getDetik()
        )

        return masuk + timedelta(
            seconds=self.__lamaParkir.toSecond()
        )

    def hitungBiaya(self):
        totalDetik = self.__lamaParkir.toSecond()

        if self.__pegawai:

            if isinstance(self.__kendaraan, Truk):
                jam = math.ceil(totalDetik / 3600)
                return self.__kendaraan.hitungBiayaUmum(jam)

            hari = math.ceil(totalDetik / 86400)
            return self.__kendaraan.hitungBiayaPegawai(hari)

        jam = math.ceil(totalDetik / 3600)

        biaya = self.__kendaraan.hitungBiayaUmum(jam)

        if self.__kunjungan >= 2:
            biaya -= biaya * 10 // 100

        return biaya

    def output(self):
        print("\n====================================")
        print("         DATA PARKIR GEDUNG")
        print("====================================")

        print("Kode Parkir    :", self.__kode)
        print("Lokasi         :", self.__lokasi)

        self.__person.output()

        print(
            "Jenis Pengguna :",
            "Pegawai" if self.__pegawai else "Umum"
        )

        if self.__pegawai:
            print("NIP            :", self.__nip)

        print("Kendaraan      :", self.__kendaraan.getJenis())
        print("Nomor Plat     :", self.__kendaraan.getNomorPlat())
        print("Tanggal Masuk  :", self.__tanggal)

        print("Jam Masuk      : ", end="")
        self.__waktuMasuk.outputWaktu()
        print()

        print("Lama Parkir    : ", end="")
        self.__lamaParkir.outputWaktu()
        print()

        waktuKeluar = self.getWaktuKeluar()

        print("Tanggal Keluar :", waktuKeluar.date())

        jamKeluar = waktuKeluar.strftime("%H:%M")

        if waktuKeluar.second != 0:
            jamKeluar += waktuKeluar.strftime(":%S")

        print("Jam Keluar     :", jamKeluar)

        if not self.__pegawai:
            print("Kunjungan      :", self.__kunjungan)

            if self.__kunjungan >= 2:
                print("Diskon         : 10%")

        print("Total Biaya    : Rp" + str(self.hitungBiaya()))
        print("====================================")


# ==================== CLASS DATA PARKIR ====================

class DataParkir:
    def __init__(self):
        self.__parkir = []
        self.__jumlah = 0

    def getParkir(self):
        return self.__parkir

    def getJumlah(self):
        return self.__jumlah

    def setParkir(self, parkir, jumlah):
        self.__parkir = parkir
        self.__jumlah = jumlah

    def hitungKunjunganMinggu(self, plat, tanggal):
        total = 0

        awal = tanggal - timedelta(days=tanggal.weekday())
        akhir = awal + timedelta(days=6)

        for p in self.__parkir:
            if (p is not None
                and not p.isPegawai()
                and p.getKendaraan().getNomorPlat().lower()
                    == plat.lower()):

                tgl = p.getTanggal()

                if awal <= tgl <= akhir:
                    total += 1

        return total

    def output(self):
        print("\n\n========== LAPORAN PARKIR ==========")

        if self.__jumlah == 0:
            print("Belum ada data parkir.")
            return

        for p in self.__parkir:
            if p is not None:
                p.output()

        print("\nJumlah Transaksi :", self.__jumlah)
        print("====================================")


# ==================== CLASS MENU ====================

class Menu:
    def __init__(self):
        self.__dataParkir = DataParkir()

    def run(self):
        print("====================================")
        print("       SISTEM PARKIR GEDUNG")
        print("====================================")

        jumlah = int(input("Jumlah data parkir: "))

        if jumlah < 1:
            print("Jumlah harus lebih dari 0.")
            return

        isi = [None] * jumlah

        for i in range(jumlah):
            print(f"\nData Parkir ke-{i + 1}")

            kode = input("Kode parkir    : ").strip()

            pilihanLokasi = int(
                input("Lokasi parkir (1. Dalam / 2. Luar): ")
            )

            if pilihanLokasi not in (1, 2):
                print("Lokasi tidak valid. Data dilewati.")
                continue

            lokasi = "Luar" if pilihanLokasi == 2 else "Dalam"

            pilihanPengguna = int(
                input("Jenis pengguna (1. Umum / 2. Pegawai): ")
            )

            if pilihanPengguna not in (1, 2):
                print("Jenis pengguna tidak valid.")
                continue

            pegawai = pilihanPengguna == 2

            nama = input("Nama           : ").strip()
            alamat = input("Alamat         : ").strip()

            nip = "-"

            if pegawai:
                nip = input("NIP            : ").strip()

            jenis = int(input(
                "Jenis kendaraan (1. Mobil / 2. Truk / 3. Motor): "
            ))

            if jenis < 1 or jenis > 3:
                print("Jenis kendaraan tidak valid.")
                continue

            plat = input("Nomor plat     : ").strip()

            tanggal = date.fromisoformat(
                input("Tanggal parkir (YYYY-MM-DD): ").strip()
            )

            print("\nMasukkan waktu masuk:")
            waktuMasuk = Waktu()
            waktuMasuk.inputWaktu()

            print("\nMasukkan lama parkir:")
            lamaParkir = Waktu()
            lamaParkir.inputWaktu()

            if (
                waktuMasuk.getJam() < 0
                or waktuMasuk.getJam() > 23
                or waktuMasuk.getMenit() < 0
                or waktuMasuk.getMenit() > 59
                or waktuMasuk.getDetik() < 0
                or waktuMasuk.getDetik() > 59
            ):
                print("Waktu masuk tidak valid.")
                continue

            if (
                lamaParkir.getJam() < 0
                or lamaParkir.getMenit() < 0
                or lamaParkir.getMenit() > 59
                or lamaParkir.getDetik() < 0
                or lamaParkir.getDetik() > 59
                or lamaParkir.toSecond() < 1
            ):
                print("Durasi parkir tidak valid.")
                continue

            if jenis == 1:
                kendaraan = Mobil(plat)
            elif jenis == 2:
                kendaraan = Truk(plat)
            else:
                kendaraan = Motor(plat)

            person = Person(nama, alamat)

            kunjunganSebelumnya = 0

            if not pegawai:
                awal = tanggal - timedelta(days=tanggal.weekday())
                akhir = awal + timedelta(days=6)

                for j in range(i):
                    if (
                        isi[j] is not None
                        and not isi[j].isPegawai()
                        and isi[j].getKendaraan().getNomorPlat().lower()
                            == plat.lower()
                    ):
                        tgl = isi[j].getTanggal()

                        if awal <= tgl <= akhir:
                            kunjunganSebelumnya += 1

                kunjunganSebelumnya += (
                    self.__dataParkir.hitungKunjunganMinggu(
                        plat, tanggal
                    )
                )

            kunjunganSaatIni = (
                0 if pegawai else kunjunganSebelumnya + 1
            )

            isi[i] = Parkir(
                kode, person, kendaraan, pegawai,
                nip, tanggal, waktuMasuk, lamaParkir,
                kunjunganSaatIni
            )

            isi[i].setLokasi(lokasi)

        lama = self.__dataParkir.getParkir()
        jumlahLama = self.__dataParkir.getJumlah()

        jumlahValid = sum(1 for p in isi if p is not None)

        gabungan = []

        gabungan.extend(lama)

        for p in isi:
            if p is not None:
                gabungan.append(p)

        self.__dataParkir.setParkir(
            gabungan,
            len(gabungan)
        )

        self.__dataParkir.output()


# ==================== MAIN PROGRAM ====================

if __name__ == "__main__":
    menu = Menu()
    menu.run()

